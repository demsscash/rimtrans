export class User {
    id: number;
    nom: string;
    login: string;
}
