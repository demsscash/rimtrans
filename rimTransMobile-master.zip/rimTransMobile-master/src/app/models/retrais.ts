export class Retrais {
    nom: string;
    prenom: string;
    tel: number;
    email: string;
    montant: number;
}
